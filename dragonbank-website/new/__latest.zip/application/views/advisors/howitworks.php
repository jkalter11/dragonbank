<p>The Enriched Academy Dragon Bank Program is a <strong>powerful</strong> resource to help advisors grow their prospect base ans strengthen client relationships. By providing the world's only kids bank, with an online learning environment for kids &amp; their parents, Advisors have an innovative, targeted and branded mechanism to connect with families &amp; help build effective saving habits in kids.</p>

<?php
/*
<div class="row">
	<div class="col-sm-8">
		some graphic here
	</div>
	<div class="col-sm-4">
		some other panel here
	</div>
</div>
*/
?>
