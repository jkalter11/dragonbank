<div class="content-body">
	<div class="row">
		<div class="col-content success">
			<div class="col-sm-5 col-sm-offset-1">
			
			<h1>Congratulations</h1>
			<p>You have successfully created your Dragon Bank online profile.</p>
			<p>Verification of your username and password has been emailed to the email address you provided along with more information on how to get the most from the Dragon Bank.</p>
			
			<h3>Thank You!</h3>
		</div>
		<div class="col-md-6">
			<div class="home-about">
				<img src="<?=ASS_IMG_PATH?>owners.png" alt="owners" class="owners" >
			</div>
		</div>
	</div>
</div>