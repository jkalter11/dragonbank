				<div class="row">
					<div class="col-content">
						<div class="col-sm-12" id="home-content">	
							<h1 style="margin: 20px 0 0 20px">Helping parents</h1>
							<h1 style="margin: 5px 0 0 100px; font-weight: 900;">TEACH MONEY SKILLS</h1>
							<h1 style="margin: 5px 0 40px 70px">to their kids.</h1>

							<ul class="ribbons">
								<li><div>Always <strong>know how much money</strong> your child HAS saved</div></li>
								<li><div><strong>Track and record</strong> every deposit accurately ONLINE!</div></li>
								<li><div><strong>Weekly email saving tips</strong></div></li>
								<li><div><strong>Set the foundation</strong> for your child's <strong>financial future</strong></div></li>
								<li><div><strong>Activities and Challenges</strong> teaching kids money lessons</div></li>
							</ul>
						</div>
					</div>
				</div>