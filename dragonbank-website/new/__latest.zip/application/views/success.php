<div class="content-body">
	<div class="row">
		<div class="col-md-5">
			<p style="font-size: 16px;">
			Congratulations, you have successfully created your Dragon Bank online profile. 
			<br/><br/>
			Verification of your username and password has been emailed to the email address you provided along with more information on how to get the most from the Dragon Bank.
			<br/><br/>
			Thank You!
			</p>
		</div>
		<div class="col-md-7">
			<div class="home-about">
				<img src="<?=ASS_IMG_PATH?>owners.png" alt="owners" class="owners" >
			</div>
		</div>
	</div>
</div>